INSERT INTO tb_funcionario (Primeiro_Nome,Nome_Meio,Ultimo_Nome,Cpf,Data_Nascimento,Endereco,Sexo,Salario,Cpf_Supervisor,Numero_Departamento)
VALUES
('João','B','Silva','12345678966','1965-09-01','Rua das Flores 751 São Paulo SP','M','30000','33344555587','5'),
('Fernando','T','Wong','33344555587','1955-08-12','Rua da Lapa 34 São Paulo SP','M','40000','88866555576','5'),
('Alice','J','Zelaya','99988777767','1968-01-19','Rua Souza Lima 35 Curitiba PR','F','25000','98765432168','4'),
('Jeniffer','S','Souza','98765432168','1941-06-20','Av Arthur de Lima 54 Santo André','F','43000','88866555576','4'),
('Ronaldo','K','Lima','66688444476','1962-09-15','Rua Rebouças 65 Piracicaba SP','M','38000','33344555587','5'),
('Joice','A','Leite','45345345376','1972-07-31','Av. Lucas Obes 74 São Paulo SP','F','25000','33344555587','5'),
('André','V','Pereira','98798798733','1969-03-29','Rua Timbira 35 São Paulo SP','M','25000','98765432168','4'),
('Jorge','E','Brito','88866555576','1937-11-10','Rua do Horto 35 Sáo Paulo SP','M','55000','','1')