INSERT INTO tb_projeto (Nome_Projeto,Numero_Projeto,Local_Projeto,Numero_Departamento)
VALUES
('Reorganização','20','São Paulo','1'),
('Produto Y','2','Itu','5'),
('Novos Benefícios','30','Mauá','4'),
('Produto X','1','Santo André','4'),
('Informatização','10','Mauá','4'),
('Produto Z','3','São Paulo','5');