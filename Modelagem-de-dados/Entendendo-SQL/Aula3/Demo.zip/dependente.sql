INSERT INTO tb_dependente (Cpf_Funcionario,Nome_Dependente,Sexo,Data_Nascimento,Parentesco)
VALUES
('33344555587','Alicia','F','1986-04-05','Filha'),
('33344555587','Tiago','M','1983-10-25','Filho'),
('33344555587','Janaína','F','1958-05-03','Esposa'),
('98765432168','Antonio','M','1942-02-18','Marido'),
('12345678966','Michael','M','1988-04-01','Filho'),
('12345678966','Alicia','F','1988-12-30','Filha'),
('12345678966','Elizabeth','F','1967-05-05','Esposa');
