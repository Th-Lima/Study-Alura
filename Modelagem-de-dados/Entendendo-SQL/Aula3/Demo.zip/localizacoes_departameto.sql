INSERT INTO tb_Localizacoes_Departamentos (Numero_departamento,Local)
VALUE (1,'São Paulo'),(4,'Mauá'),(5,'Santo André'),(5,'Itu'),(5,'São Paulo');