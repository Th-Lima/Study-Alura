INSERT INTO tb_departamento (Nome_Departamento,Numero_Departamento,Cpf_Gerente,Data_Inicio_Gerente)
VALUES ('Pesquisa',5,'33344555587','1988-05-22'),
('Administração',4,'98765432168','1995-01-01'),
('Matriz',1,'88866555576','1981-06-19');