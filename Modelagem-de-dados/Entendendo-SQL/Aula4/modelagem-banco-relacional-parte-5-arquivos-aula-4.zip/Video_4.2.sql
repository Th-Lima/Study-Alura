SELECT * FROM tb_projeto;

SELECT nome_projeto, numero_projeto FROM tb_projeto;

SELECT nome_projeto AS 'NOME DO PROJETO'
, numero_projeto AS 'NUMERO DO PROJETO' FROM tb_projeto;

